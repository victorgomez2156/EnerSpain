<section class="content">
<div class="alert alert-<?php echo $type ?> alert-dismissable">
	<i class="<?php echo $icon ?>"></i>
	<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
	<b><?php echo $title ?></b>
	<p><?php echo $msg ?></p>
</div>
</section>