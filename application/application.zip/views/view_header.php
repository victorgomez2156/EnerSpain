  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="">
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
  <meta name="viewport" content="width=device-width" />
  <meta name="csrf-token" content="35s4o9Bjow5OU2qha7E5cEWHIRif31AHQa44IYEQ">
  <link rel="shortcut icon" href="<?php echo ESTILOS;?>img/logo-big.png" >
  
   <!-- Bootstrap CSS -->
  <link href="<?php echo ESTILOS;?>css/bootstrap.min.css" rel="stylesheet">
  <!-- bootstrap theme -->
  <link href="<?php echo ESTILOS;?>css/bootstrap-theme.css" rel="stylesheet">
  <!--external css-->
  <!-- font icon -->
  <link href="<?php echo ESTILOS;?>css/elegant-icons-style.css" rel="stylesheet" />
  <link href="<?php echo ESTILOS;?>css/font-awesome.min.css" rel="stylesheet" />
  <!-- Custom styles -->
  <link href="<?php echo ESTILOS;?>css/style.css" rel="stylesheet">
  <link href="<?php echo ESTILOS;?>css/style-responsive.css" rel="stylesheet" />
  <link href="<?php echo ESTILOS;?>css-loader-master/dist/css-loader.css" rel="stylesheet" />
  <link href="<?php echo ESTILOS;?>css/sweetalert2.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="<?php echo ESTILOS;?>css/datepicker.css" />
  <link rel="stylesheet" href="<?php echo ESTILOS;?>css/bootstrap-timepicker.css" />
  <link rel="stylesheet" href="<?php echo ESTILOS;?>css/daterangepicker.css" />
  <link rel="stylesheet" href="<?php echo ESTILOS;?>css/bootstrap-datetimepicker.css" />
  <link rel="stylesheet" href="<?php echo ESTILOS;?>css/colorpicker.css" />  
  <link href="<?php echo ESTILOS;?>css/jquery-ui-1.10.4.min.css" rel="stylesheet">
  <link rel="stylesheet" href="<?php echo ESTILOS;?>css/toastr.css" />

  <script src="<?php echo ESTILOS.'js/jquery-3.2.1.min.js'?>"></script>

   <script src="<?php echo PATH_ESTILOS_JS.'angular.js'?>"></script>
   <script src="<?php echo PATH_ESTILOS_JS.'angular-animate.min.js'?>"></script>
   <script src="<?php echo PATH_ESTILOS_JS.'angular-aria.min.js'?>"></script>
   <script src="<?php echo PATH_ESTILOS_JS.'angular-material.js'?>"></script>
   <script src="<?php echo PATH_ESTILOS_JS.'assets-cache.js'?>"></script>  


  <script src="<?php echo PATH_ESTILOS_JS.'angular-cookies.js'?>"></script> 
  <script src="<?php echo PATH_ESTILOS_JS.'checklist-model.js'?>"></script> 
  <script src="<?php echo PATH_ESTILOS_JS.'angular-resource.js'?>"></script>
  <script src="<?php echo PATH_ESTILOS_JS.'angular-ping.js'?>"></script> 

  <script src="<?php echo PATH_ESTILOS_JS.'angular-route.js'?>"></script> 
  <script src="<?php echo PATH_ESTILOS_JS.'ng-files-model.js'?>"></script>
  <script src="<?php echo PATH_ESTILOS_JS.'bootstrap-typeahead.js'?>"></script>
  <script src="<?php echo PATH_ESTILOS_JS.'ui-bootstrap-tpls-0.11.0.js'?>"></script>
  <!--script src="<?php echo PATH_ESTILOS_JS.'angular-translate.min.js'?>"></script-->
  <!--script src="<?php echo ESTILOS.'js/jquery.maskedinput.js'?>"></script--> 
  
  <!--Final de Principales de ANGULARJS-->
  <!--Inicio de Librerias del sistema con ANGULARJS-->
  <script src="<?php echo PATH_ESTILOS_JS_APP.'appPrincipal.js'?>"></script>
  <script src="<?php echo PATH_ESTILOS_JS_APP.'funciones.js'?>"></script>
  <script src="<?php echo PATH_ESTILOS_JS_APP.'servicios.js'?>"></script>
  
  <script src="<?php echo PATH_ESTILOS_JS_APP.'dashboard.js'?>"></script>
  <script src="<?php echo PATH_ESTILOS_JS_APP.'empleados.js'?>"></script>  
  <script src="<?php echo PATH_ESTILOS_JS_APP.'distribuidora.js'?>"></script>  
  <script src="<?php echo PATH_ESTILOS_JS_APP.'colaboradores.js'?>"></script> 
  <script src="<?php echo PATH_ESTILOS_JS_APP.'cups.js'?>"></script>
  <script src="<?php echo PATH_ESTILOS_JS_APP.'consumo_cups.js'?>"></script>
  
  <script src="<?php echo PATH_ESTILOS_JS_APP.'comercializadora.js'?>"></script>
  <script src="<?php echo PATH_ESTILOS_JS_APP.'datos_basicos_comercializadora.js'?>"></script>
  <script src="<?php echo PATH_ESTILOS_JS_APP.'productos.js'?>"></script>
  <script src="<?php echo PATH_ESTILOS_JS_APP.'anexos.js'?>"></script>
  <script src="<?php echo PATH_ESTILOS_JS_APP.'servicios_especiales.js'?>"></script>
  
  <script src="<?php echo PATH_ESTILOS_JS_APP.'clientes.js'?>"></script>
  <script src="<?php echo PATH_ESTILOS_JS_APP.'datos_basicos_clientes.js'?>"></script>
  <script src="<?php echo PATH_ESTILOS_JS_APP.'actividades.js'?>"></script>
  <script src="<?php echo PATH_ESTILOS_JS_APP.'puntos_suministros.js'?>"></script>
  <script src="<?php echo PATH_ESTILOS_JS_APP.'contactos.js'?>"></script>
  <script src="<?php echo PATH_ESTILOS_JS_APP.'cuentas_bancarias.js'?>"></script>
  <script src="<?php echo PATH_ESTILOS_JS_APP.'documentos.js'?>"></script>
  <script src="<?php echo PATH_ESTILOS_JS_APP.'comisiones.js'?>"></script>
  <script src="<?php echo PATH_ESTILOS_JS_APP.'comisiones_servicios_adicionales.js'?>"></script>
  
  <script src="<?php echo PATH_ESTILOS_JS_APP.'tarifas.js'?>"></script>
  <script src="<?php echo PATH_ESTILOS_JS_APP.'tipos.js'?>"></script>
  <script src="<?php echo PATH_ESTILOS_JS_APP.'motivos_bloqueos.js'?>"></script>
  <script src="<?php echo PATH_ESTILOS_JS_APP.'comercial.js'?>"></script>
  <script src="<?php echo PATH_ESTILOS_JS_APP.'menu.js'?>"></script>  
  <script src="<?php echo PATH_ESTILOS_JS_APP.'logs.js'?>"></script>

  <script src="<?php echo PATH_ESTILOS_JS_APP.'propuestas_comerciales.js'?>"></script>
  <script src="<?php echo PATH_ESTILOS_JS_APP.'add_propuestas_comerciales.js'?>"></script>
  <script src="<?php echo PATH_ESTILOS_JS_APP.'add_propuesta_comercial_UniCliente.js'?>"></script>
  <script src="<?php echo PATH_ESTILOS_JS_APP.'add_propuesta_comerciales_MulCliente.js'?>"></script>
  
  <script src="<?php echo PATH_ESTILOS_JS_APP.'contratos.js'?>"></script>
  <script src="<?php echo PATH_ESTILOS_JS_APP.'renovacion_masiva.js'?>"></script>   
  <script src="<?php echo PATH_ESTILOS_JS_APP.'otras_gestiones.js'?>"></script>
  <script src="<?php echo PATH_ESTILOS_JS_APP.'seguimientos.js'?>"></script>  

  <script src="<?php echo PATH_ESTILOS_JS_APP.'proyeccion_ingresos.js'?>"></script>
  <script src="<?php echo PATH_ESTILOS_JS_APP.'ingresos_reales.js'?>"></script>
  <script src="<?php echo PATH_ESTILOS_JS_APP.'ingresos_vs_proyectado.js'?>"></script>
  <script src="<?php echo PATH_ESTILOS_JS_APP.'rueda.js'?>"></script>
 
  <!--script src="<?php echo PATH_ESTILOS_JS_APP.'menu.js'?>"></script-->
  <!--script src="<?php echo PATH_ESTILOS_JS_APP.'provincia.js'?>"></script>
  <script src="<?php echo PATH_ESTILOS_JS_APP.'clientes.js'?>"></script>
  <script src="<?php echo PATH_ESTILOS_JS_APP.'localidad.js'?>"></script>
  <script src="<?php echo PATH_ESTILOS_JS_APP.'tipo_cliente.js'?>"></script>
  <script src="<?php echo PATH_ESTILOS_JS_APP.'bancos.js'?>"></script>
  <script src="<?php echo PATH_ESTILOS_JS_APP.'tipos_vias.js'?>"></script>
  <script src="<?php echo PATH_ESTILOS_JS_APP.'motivos_bloqueos.js'?>"></script>  
  <script src="<?php echo PATH_ESTILOS_JS_APP.'sectores.js'?>"></script>
  <script src="<?php echo PATH_ESTILOS_JS_APP.'tipo_inmueble.js'?>"></script>  
  <script src="<?php echo PATH_ESTILOS_JS_APP.'motivos_bloqueos_actividades.js'?>"></script>
  <script src="<?php echo PATH_ESTILOS_JS_APP.'bloqueo_pum_sum.js'?>"></script>
   <script src="<?php echo PATH_ESTILOS_JS_APP.'bloqueo_contacto.js'?>"></script>
  <script src="<?php echo PATH_ESTILOS_JS_APP.'tarifa_electrica.js'?>"></script>
  <script src="<?php echo PATH_ESTILOS_JS_APP.'tarifa_gas.js'?>"></script>
  <script src="<?php echo PATH_ESTILOS_JS_APP.'tipo_comision.js'?>"></script>
  <script src="<?php echo PATH_ESTILOS_JS_APP.'tipo_contacto.js'?>"></script>
  <script src="<?php echo PATH_ESTILOS_JS_APP.'bloqueo_comercializadora.js'?>"></script>
  <script src="<?php echo PATH_ESTILOS_JS_APP.'configuraciones_sistema.js'?>"></script-->
  <!--script src="<?php echo ESTILOS;?>js/bloqueador.js"></script-->    
  <title>Bienvenido: <?php echo $this->usuario;?> | <?php echo TITULO;?>"></title>
  <style>
  body { padding-right: 0 !important }
  
.btn-icon
{
    padding: 8px 9px 8px 10px !important;
    width: 53px !important;

}
.btn-credenciales
{
    padding: 8px 9px 8px 5px !important;
    width: auto !important;

}
.oscuro{ 
  color:#1f1f1f;
    background-color: #1f1f1f; 
    color: #f1eded; 
}
.td-usuario-table{
    margin-top: 17px;
}

.title_table{
    color: #0a78d0;
    font-weight: bold;
}

.btn-primary{
    color: #fff;
    background-color: #6d6e71 !important;
    border-color: #6d6e71!important;
    box-shadow: none !important;
    margin-bottom: 10px !important;
}
.btn-primary:hover{
    box-shadow: 0 14px 26px -12px rgba(153, 153, 153, 0.42), 0 4px 23px 0px rgba(0, 0, 0, 0.12), 0 8px 10px -5px rgba(153, 153, 153, 0.2) !important;
}

#mydiv {  
    position:absolute;
    top:0;
    left:0;
    width:100%;
    height:100%;
    z-index:1000;
    background-color:grey;
    opacity: .8;
 }

.ajax-loader {
    position: absolute;
    left: 50%;
    top: 50%;
    margin-left: -32px; /* -1 * image width / 2 */
    margin-top: -32px;  /* -1 * image height / 2 */
    display: block;     
}

  </style>
